// Created by jwoeste on 5/30/24.
//
#include <fstream>
#include <iostream>
#include <random>
#include <algorithm>
//              [THIS IS THE COPY VERSION MEANT TO BALANCE THE CASE WHERE FD CAN BE 0,1,or 2!!!]
using namespace std;

class BalanceData {
public:
    BalanceData(const string &filename) {
        readFileLines(filename);
        balanceData();
    }

    vector<string> getBalancedData() {
        return balancedData;
    }

private:
    vector<string> fileLines;
    vector<string> balancedData;

    void readFileLines(const string &filename) {
        ifstream file(filename);

        if (!file.is_open()) {
            cout << "Error opening input file, please check file name!" << endl;
            exit(1);
        }

        string line;
        getline(file, line); // read and discard the header
        while (getline(file, line)) {
            fileLines.push_back(line); // store each line in the vector
        }

        file.close();
    }

    vector<string> getRandomSample(const vector<string> &data, size_t sampleSize) {
        vector<string> sample = data;
        random_device rd;
        mt19937 g(rd());
        shuffle(sample.begin(), sample.end(), g);
        sample.resize(sampleSize);
        return sample;
    }

    void balanceData() {
        // Separate lines into FD=1, FD=0, and FD=2
        vector<string> fd1Lines;
        vector<string> fd0Lines;
        vector<string> fd2Lines;
        for (const string &line : fileLines) {
            size_t pos = line.rfind(',');

            int fd = stoi(line.substr(pos + 1));
            if (fd == 1) {
                fd1Lines.push_back(line);
            } else if (fd == 0) {
                fd0Lines.push_back(line);
            } else if (fd == 2) {
                fd2Lines.push_back(line);
            }
        }

        // Determine the smallest group size
        size_t minSize = min({fd1Lines.size(), fd0Lines.size(), fd2Lines.size()});

        // Sample the larger groups to match the smallest group size
        if (fd1Lines.size() > minSize) {
            fd1Lines = getRandomSample(fd1Lines, minSize);
        }
        if (fd0Lines.size() > minSize) {
            fd0Lines = getRandomSample(fd0Lines, minSize);
        }
        if (fd2Lines.size() > minSize) {
            fd2Lines = getRandomSample(fd2Lines, minSize);
        }

        // Combine the balanced data
        balancedData = fd1Lines;
        balancedData.insert(balancedData.end(), fd0Lines.begin(), fd0Lines.end());
        balancedData.insert(balancedData.end(), fd2Lines.begin(), fd2Lines.end());

    }
};