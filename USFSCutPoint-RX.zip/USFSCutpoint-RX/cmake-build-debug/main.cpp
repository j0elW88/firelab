#include <iostream>
#include <cmath>
#include <map>
#include <fstream>
#include <vector>
#include <string>
#include <array>
#include "BalanceData.cpp"
#include "StoreMatrix.cpp"
#include <unordered_map>


using namespace std;

vector<pair<float, int>> track_values(const vector<float>& bestERCvals) {
    unordered_map<float, int> count_map;

    // Count occurrences of each value
    for (float val : bestERCvals) { // Change int to float here
        count_map[val]++;
    }

    // Convert counts to a vector of pairs
    vector<pair<float, int>> counts_vector(count_map.begin(), count_map.end());
    return counts_vector;
}

float calculateMedian(vector<float>& values) {  //Median Calculator (not currently used)
    size_t size = values.size();
    sort(values.begin(), values.end());

    if (size % 2 == 0) {
        return (values[size / 2 - 1] + values[size / 2]) / 2;
    } else {
        return values[size / 2];
    }
}



int main() {

    //For Logistical Regression Model Include more input checks here
    // inorder to view land type, then also make another tally system to track these vals and calculate output.
    // Do same thing except have it run through slightly different parameters.

    cout << "Values Input Will Calculate Everything below the input Value " << endl;
    cout << "This should run through all possible forest fire predictions/ERC cutoff" << endl;

    int weight1;
    int weight2;
    int iterationNum;

    float ERCscale11;   //ERC SCALE 1:4 is FN:FP
    float ERCscale12;   //ERC SCALE 1:2 is FN:FP
    // float ERCscale1_1; //We don't really need this one but its cool to calculate
    float ERCscale21;   //ERC SCALE 2:1 is FN:FP

    float ERCscale11_2;   //ERC SCALE 1:4 is FN:FP
    float ERCscale12_2;   //ERC SCALE 1:2 is FN:FP
    // float ERCscale1_1; //We don't really need this one but its cool to calculate
    float ERCscale21_2;   //ERC SCALE 2:1 is FN:FP


    cout << "How many iterations do you wish to run?: ";
    cin >> iterationNum;
    cout << endl;

    int numRuns = 3;  //Program runs 4 times to find all scales!
    for(int scaleRun = 0; scaleRun < numRuns; scaleRun++) { //implement this, put bracket at end and put test statements for i to determine where the val is being stored in weight.
        if (scaleRun == 0) {
            weight1 = 1;
            weight2 = 1;
        }
        if (scaleRun == 1) {
            weight1 = 1;
            weight2 = 2;
        }
        if (scaleRun == 2) {
            weight1 = 2;
            weight2 = 1;
        }


        vector<float> bestERCvals;
        vector<float> bestERCvals2;

        for (int iteration = 0; iteration < iterationNum; ++iteration) {

            BalanceData balanceData("fullfire.csv");
            vector<string> balancedData = balanceData.getBalancedData();
            vector<pair<float, int>> ercFrequencyMap; //map to track the frequency of certain ERC vals


            float minCost = 999999999;
            float bestERC = 0.0;

            float minCost2 = 999999999;
            float bestERC2 = 0.0;

            for (float i = 0.00; i <= 1; i += 0.01) {
                float testVal = i; // put the other bracket at end
                float testVal2 = i;
               // cout << endl;
               // cout << "Current Alpha Value: " << i << endl; //This Displays Which Alpha val youre currently at [3]

                // float testVal = 0.01;

                int totalFP = 0;
                int totalFN = 0;
                int totalTP = 0;
                int totalTN = 0;

                int totalFP2 = 0;
                int totalFN2 = 0;
                int totalTP2 = 0;
                int totalTN2 = 0;

                StoreMatrix storeMatrix;
                StoreMatrix storeMatrix2;

                for (const string &line: balancedData) {
                    try {

                        //***[USE THIS FUNCTION IF DATA DOESNT HAVE EXTRA LINE INFRONT!!!]***
                        /*size_t pos = 0;

                        pos = line.find(',');
                        string date = line.substr(0, pos); // Read date
                        string remainingLine = line.substr(pos + 1);

                        pos = remainingLine.find(',');
                        float erc = stof(remainingLine.substr(0, pos)); // Read ERC

                        //erc = round(erc * 100) / 100; //ROUNDING ERC to the 100th PLACE REMOVE!!!

                        remainingLine = remainingLine.substr(pos + 1);
                        int FD = stoi(remainingLine); // Read Fire Occurrence
                         */

                        //***[USE THIS FUNCTION IF FILE HAS A FIRST LINE YOU NEED TO IGNORE!!!]***
                        size_t pos = line.find(',');            //Skips line num csv
                        string linenum = line.substr(0, pos); //this line can probably be deleted
                        string remainingLine = line.substr(pos + 1);
                        linenum.clear(); //can be removed

                        pos = remainingLine.find(',');
                        string date = remainingLine.substr(0, pos); // Read date
                        remainingLine = remainingLine.substr(pos + 1); //add "string" to start and delete above if no line number included.


                        pos = remainingLine.find(',');
                        float erc = stof(remainingLine.substr(0, pos)); // Read ERC

                        // erc = round(erc * 100) / 100; //ROUNDING ERC to the 100th PLACE REMOVE!!!

                        //This will change if you introduce either text or 012 for No Fire, Fire, or Prescribed Fire
                        remainingLine = remainingLine.substr(pos + 1);
                        int FD = stoi(remainingLine); // Read Fire Occurrence


                        //Edit these predictions based on what output should be

                        int tpr = 0;
                        int tnr = 0;
                        int fpr = 0;
                        int fnr = 0;

                        float erc2 = erc;
                        int tpr2 = 0;
                        int tnr2 = 0;
                        int fpr2 = 0;
                        int fnr2 = 0;

                        if (erc >= testVal && FD == 1) {
                            tpr = 1;
                            tnr = 0; // prediction is fire & there was a fire
                            fpr = 0;
                            fnr = 0;
                            // break;
                        }
                        if (erc >= testVal && FD == 0) {
                            tpr = 0;
                            tnr = 0; // prediction is fire & there was no fire.
                            fpr = 1;
                            fnr = 0;
                            // break;
                        }
                        if (erc < testVal && FD == 0) {
                            tpr = 0;
                            tnr = 1; // prediction is no fire & there was no fire.
                            fpr = 0;
                            fnr = 0;
                            // break;
                        }
                        if (erc < testVal && FD == 1) {
                            tpr = 0;
                            tnr = 0; // prediction is no fire & there was a fire.
                            fpr = 0;
                            fnr = 1;
                            // break;
                        }


                        if (erc2 <= testVal2 && FD == 1) {
                            tpr2 = 1;
                            tnr2 = 0; //
                            fpr2 = 0;
                            fnr2 = 0;
                            // break;
                        }
                        if (erc2 <= testVal2 && FD == 2) {
                            tpr2 = 0;
                            tnr2 = 0; //
                            fpr2 = 1;
                            fnr2 = 0;
                            // break;
                        }
                        if (erc2 > testVal2 && FD == 2) {
                            tpr2 = 0;
                            tnr2 = 1; //
                            fpr2 = 0;
                            fnr2 = 0;
                            // break;
                        }
                        if (erc2 > testVal2 && FD == 1) {
                            tpr2 = 0;
                            tnr2 = 0; //
                            fpr2 = 0;
                            fnr2 = 1;
                            // break;
                        }

                        storeMatrix.addConfusionMatrix(erc, tpr, tnr, fpr,fnr); // will be used to make the prediction/obs matrix
                        storeMatrix2.addConfusionMatrix(erc2, tpr2, tnr2, fpr2, fnr2);


                    } catch (const invalid_argument &e) {
                        cerr << "Error: Invalid argument encountered while parsing the input data." << endl;
                        cerr << "Details: " << e.what()
                             << endl; // Handle the invalid argument exception There is one piece of data formatted weird
                    }
                }

                //this function tallies up the ERC's each iteration of the Matrix
                for (const auto &entry: storeMatrix._oneTallies) {
                    float targetERC = entry.first; // Tallies for each ERC Val
                    auto tallies = storeMatrix.getOneTallies(targetERC);

                    //this displays the tallies for each erc every matrix.
                    // cout << "Tallies for ERC " << targetERC << ": TPR=" << tallies[0] << ", TNR=" << tallies[1] //[2]
                     //<< ", FPR=" << tallies[2] << ", FNR=" << tallies[3] << endl; //[2]


                    totalTP += tallies[0];
                    totalTN += tallies[1];
                    totalFP += tallies[2];
                    totalFN += tallies[3];
                }




                float cost = 0;
                cost = ((weight1 * totalFN) + (weight2 * totalFP));     //Misclassification cost calculator
                //cout << "Missclassification Cost: " << cost << endl; [3]

                if (cost < minCost) {
                    minCost = cost;             //record lowest cost
                    bestERC = testVal;          //record current ERC being tested

                }


                for (const auto &entry: storeMatrix2._oneTallies) {
                    float targetERC = entry.first; // Tallies for each ERC Val
                    auto tallies = storeMatrix2.getOneTallies(targetERC);

                    totalTP2 += tallies[0];
                    totalTN2 += tallies[1];
                    totalFP2 += tallies[2];
                    totalFN2 += tallies[3];
                }

                //displays the total tallies for each ERC after compiling all the matrixes in the input file
                //cout << "Tallies for each ERC" << endl; //[3]
                //cout << "TP: " << totalTP2 << " TN: " << totalTN2 << " FP: " << totalFP2 << " FN: " << totalFN2 << " " << endl; //[3]

                float cost2;
                cost2 = ((weight1 * totalFN2) + (weight2 * totalFP2));

                if (cost2 < minCost2) {
                    minCost2 = cost2;             //record lowest cost
                    bestERC2 = testVal2;          //record current ERC being tested

                }
            }

            //cout << "---------------------------------------------------------------" << endl;
            //cout << endl;
            //cout << "          Lowest Misclass Cost: " << minCost2 << " at ERC: " << bestERC2 << endl;
            //cout << endl;
            //cout << "---------------------------------------------------------------" << endl;

            bestERCvals.push_back(bestERC);
            bestERCvals2.push_back(bestERC2);
        }


        //Function calculates ERC by finding the MAX and then outputs as opposed to other function calculating MEDIAN

        float maxERCcount = -999999;
        float maxERCcount2 = -999999;

        // Output the result
        for (const auto &pair: track_values(bestERCvals)) {     //[4]
            float tempVar = pair.second;
            float tempVal = pair.first;
            //Use this if you want to see the individual percentages or possible bounds of ERCs
            //cout << "Value: " << pair.first << ", Count: " << pair.second << ", Percentage: " << float((tempVar / iterationNum) * 100) << "%" << endl;

            //Function calculates ERC by finding the max and then outputs
            if (maxERCcount == tempVar) {
                if (scaleRun == 0) {
                    ERCscale11 = (tempVal + ERCscale11)/2;
                    cout << "splitting middle for 1:1" << endl;
                }
                if (scaleRun == 1) {
                    ERCscale12 = (tempVal + ERCscale12)/2;
                    cout << "splitting middle for 1:2" << endl;
                }
                if (scaleRun == 2) {
                    ERCscale21 = (tempVal + ERCscale21)/2;
                    cout << "splitting middle for 2:1" << endl;
                }
                maxERCcount = tempVar;
                cout << endl;
            }else if(maxERCcount < tempVar) {
                if (scaleRun == 0) {
                    ERCscale11 = tempVal;
                    cout << "Loading No Fire v. Wildfire 1:1..." << endl;
                }
                if (scaleRun == 1) {
                    ERCscale12 = tempVal;
                    cout << "Loading No Fire v. Wildfire 1:2..." << endl;
                }
                if (scaleRun == 2) {
                    ERCscale21 = tempVal;
                    cout << "Loading No Fire v. Wildfire 2:1..." << endl;
                }
                maxERCcount = tempVar;
            }

        }

        for (const auto &pair: track_values(bestERCvals2)) {     //[4]
            float tempVar = pair.second;
            float tempVal = pair.first;
            //Use this if you want to see the individual percentages or possible bounds of ERCs
            //cout << "Value: " << pair.first << ", Count: " << pair.second << ", Percentage: " << float((tempVar / iterationNum) * 100) << "%" << endl;

            //Function calculates ERC by finding the max and then outputs
            if (maxERCcount2 == tempVar) {
                if (scaleRun == 0) {
                    ERCscale11_2 = (tempVal + ERCscale11_2)/2;
                    cout << "Splitting middle for 1:1" << endl;
                }
                if (scaleRun == 1) {
                    ERCscale12_2 = (tempVal + ERCscale12_2)/2;
                    cout << "Splitting middle for 1:2" << endl;
                }
                if (scaleRun == 2) {
                    ERCscale21_2 = (tempVal + ERCscale21_2)/2;
                    cout << "Splitting middle for 2:1" << endl;
                }
                maxERCcount2 = tempVar;
                cout << endl;
            }else if(maxERCcount2 < tempVar) {
                if (scaleRun == 0) {
                    ERCscale11_2 = tempVal;
                    cout << "Loading Missed-Prescribed v. Missed-Wildfire 1:1..." << endl;
                }
                if (scaleRun == 1) {
                    ERCscale12_2 = tempVal;
                    cout << "Loading Missed-Prescribed v. Missed-Wildfire 1:2..." << endl;
                }
                if (scaleRun == 2) {
                    ERCscale21_2 = tempVal;
                    cout << "Loading Missed-Prescribed v. Missed-Wildfire 2:1..." << endl;
                }
                maxERCcount2 = tempVar;
            }


        }

       /* //Comment this part out and uncomment above to calculate using the MAX values for highest bounds.
       //This code gives the median cut-point options!
        float medianERC = calculateMedian(bestERCvals);

        if (scaleRun == 0) {
            ERCscale14 = medianERC;
            cout << "Calculating Median 1:4 ..." << endl;
        } else if (scaleRun == 1) {
            ERCscale12 = medianERC;
            cout << "Calculating Median 1:2 ..." << endl;
        } else if (scaleRun == 2) {
            ERCscale21 = medianERC;
            cout << "Calculating Median 2:1 ..." << endl;
        } else if (scaleRun == 3) {
            ERCscale41 = medianERC;
            cout << "Calculating Median 4:1 ..." << endl;
        }
    */


    }
    ERCscale11 = round(ERCscale11 * 1000) / 1000; //ROUNDING ERC to the 100th PLACE
    ERCscale12 = round(ERCscale12 * 1000) / 1000; //ROUNDING ERC to the 100th PLACE
    ERCscale21 = round(ERCscale21 * 1000) / 1000; //ROUNDING ERC to the 100th PLACE

    ERCscale11_2 = round(ERCscale11_2 * 1000) / 1000; //ROUNDING ERC to the 100th PLACE
    ERCscale12_2 = round(ERCscale12_2 * 1000) / 1000; //ROUNDING ERC to the 100th PLACE
    ERCscale21_2 = round(ERCscale21_2 * 1000) / 1000; //ROUNDING ERC to the 100th PLACE


    cout << endl;
    cout << "No Fire v. Predicted" << endl;
    cout << "Optimal Cutpoint 1:1 FN:FP: " << ERCscale11 << endl;
    cout << "Optimal Cutpoint 1:2 FN:FP: " << ERCscale12 << endl;
    cout << "Optimal Cutpoint 2:1 FN:FP: " << ERCscale21 << endl;

    cout << endl;
    cout << "Prescribed v. Wildfire" << endl;
    cout << "Optimal Cutpoint 1:1 FN:FP: " << ERCscale11_2 << endl;
    cout << "Optimal Cutpoint 1:2 FN:FP: " << ERCscale12_2 << endl;
    cout << "Optimal Cutpoint 2:1 FN:FP: " << ERCscale21_2 << endl;

    return 0;
}
