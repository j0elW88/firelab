HOW CUTPOINT WORKS or Cutpoint Analysis Program Works

This is the first version of cutpoint analysis, and is the most basic. This only runs a cutpoint
on data formatted in a very specific way. 

This program is a pre-make of the USFSCUTPOINT_IMPORT_NP so it functions slightly different than whats below\
The main difference is that it only intakes a very limited.

This requires FD to already be merged and to include Line number, Date, ERC and FD

Below is not exactly how this program works, but follows most of the same logic so I will include it.

Cutpoint Works by intaking a file that contains a percentiled (or not) value as a anchor for another input of binary data,
in previous test cases we have used the example of ERC_PRC and FD. These two outputs can be
obtained through running USFS_NP_SORT that compiles IFAD and Weather data to create accurate
merged FD, also able to run equations on DATA. 

This program works very generally to allow for variability in data inputs!
This program intakes the data, and randomly samples until the size of the larger
binary line is equal in size, FD = 0 is equal in size to FD = 1.
After this is achieved it will assign the values True Posotive, True Negative, False Posotive, and False Negative Values
Currently Only the False Posotive and Negative Cases are considered for ERC ranking, the posotive cases
are used to evaluate total outcome accuracy. After data is sorted into TP TN FP FN, the anchor values or ERC's are tallied
whichever value for that run has the least cost after a weighting cost is applied. After the optimal erc for this run is found, depending on the users run amount,
the program will recompile for that amount of times over again. After recompiling x amount of times, the 
best ERC or the most frequently achieved ERC from each of these runs is found, and if it is split between the middle, it will take the average between the two
After this, the program runs through the different weight categories assigned. Standard as of now
it runs through a 1:5, 1:2, 1:1, 2:1, 5:1 weighting scale, which should ultimately output your cutpoint values.
