/*#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

class ConfusionMatrix {
public:
    ConfusionMatrix() : ERC(0), TPR(0), TNR(0), FPR(0), FNR(0) {}
    ConfusionMatrix(float ERC, int TPR, int TNR, int FPR, int FNR) : ERC(ERC), TPR(TPR), TNR(TNR), FPR(FPR), FNR(FNR) {}

    float getERC() const { return ERC; }
    int getTPR() const { return TPR; }
    int getTNR() const { return TNR; }
    int getFPR() const { return FPR; }
    int getFNR() const { return FNR; }

    friend ostream& operator<<(ostream& os, const ConfusionMatrix& confusionMatrix) {
        os << confusionMatrix.ERC << " ";  // ERC
        os << confusionMatrix.TPR << " ";   // TPR
        os << confusionMatrix.TNR << " ";   // TNR
        os << confusionMatrix.FPR << " ";   // FPR
        os << confusionMatrix.FNR << endl;  // FNR
        return os;
    }
private:
    float ERC;
    int TPR;
    int TNR;
    int FPR;
    int FNR;
};

*/