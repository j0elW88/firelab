//
// Created by jwoeste on 5/28/24.
//

#ifndef CUTPOINT_CONFUSIONMATRIX_H
#define CUTPOINT_CONFUSIONMATRIX_H


class ConfusionMatrix {

};


#endif //CUTPOINT_CONFUSIONMATRIX_H
