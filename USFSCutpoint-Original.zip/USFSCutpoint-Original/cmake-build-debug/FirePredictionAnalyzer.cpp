
//utilize with oldmain.cpp!



/* #include <iostream>
#include <cmath>
#include <map>
#include <fstream>
#include <vector>
#include <string>
#include <array>
#include <algorithm>
#include <unordered_map>
#include "MisclassificationCost.cpp"
#include "BalanceData.cpp"
#include "StoreMatrix.cpp"

using namespace std;

vector<pair<float, int>> track_values(const vector<float>& bestERCvals) {
    unordered_map<float, int> count_map;

    // Count occurrences of each value
    for (float val : bestERCvals) { // Change int to float here
        count_map[val]++;
    }

    // Convert counts to a vector of pairs
    vector<pair<float, int>> counts_vector(count_map.begin(), count_map.end());
    return counts_vector;
}

class FirePredictionAnalyzer {
public:
    FirePredictionAnalyzer(const string& filename, float weight1, float weight2, int iterationNum)
            : filename(filename), weight1(weight1), weight2(weight2), iterationNum(iterationNum) {}

    void runAnalysis() {
        for (int iteration = 0; iteration < iterationNum; ++iteration) {

            BalanceData balanceData(filename);
            vector<string> balancedData = balanceData.getBalancedData();
            vector<pair<float, int>> ercFrequencyMap; //map to track the frequency of certain ERC vals

            float minCost = 999999999;
            float bestERC = 0.0;
            //float minCost2 = 999999999;
            //float bestERC2 = 0.0;

            for (float i = 0.00; i <= 1; i += 0.01) {
                float testVal = i; // put the other bracket at end
                //cout << endl;
                //cout << "Current Alpha Value: " << i << endl; //This Displays Which Alpha val youre currently at [3]

                // float testVal = 0.01;

                int totalFP = 0;
                int totalFN = 0;
                int totalTP = 0;
                int totalTN = 0;

                vector<ConfusionMatrix> predFireAccuracy; // Create a vector for the data for the imported Data (ERC is attached to the Matrix)
                // map<string, ConfusionMatrix> predFireAccuracyWithDate; //the same but instead a map with date just in-case needed at some-point! [NOT IN USE]
                StoreMatrix storeMatrix;

                for (const string &line: balancedData) {
                    try {
                        parseLine(line, testVal, totalTP, totalTN, totalFP, totalFN, storeMatrix);

                    } catch (const invalid_argument &e) {
                        cerr << "Error: Invalid argument encountered while parsing the input data." << endl;
                        cerr << "Details: " << e.what() << endl; // Handle the invalid argument exception There is one piece of data formatted weird
                    }
                }

                //this function tallies up the ERC's each iteration of the Matrix
                for (const auto &entry: storeMatrix._oneTallies) {
                    float targetERC = entry.first; // Tallies for each ERC Val
                    auto tallies = storeMatrix.getOneTallies(targetERC);

                    //this displays the tallies for each erc every matrix.
                    /* cout << "Tallies for ERC " << targetERC << ": TPR=" << tallies[0] << ", TNR=" << tallies[1] //[2]
                     << ", FPR=" << tallies[2] << ", FNR=" << tallies[3] << endl; //[2]
                    */
/*
                    totalTP += tallies[0];
                    totalTN += tallies[1];
                    totalFP += tallies[2];
                    totalFN += tallies[3];
                }

                //displays the total tallies for each ERC after compiling all the matrixes in the input file
                //cout << "Tallies for each ERC" << endl; //[3]
                //cout << "TP: " << totalTP << " TN: " << totalTN << " FP: " << totalFP << " FN: " << totalFN << " " << endl; //[3]

                float cost = 0;
                cost = ((weight1 * totalFP) + (weight2 * totalFN));     //Misclassification cost calculator
                //cout << "Missclassification Cost: " << cost << endl; [3]

                if (cost < minCost) {
                    minCost = cost;             //record lowest cost
                    bestERC = testVal;          //record current ERC being tested
                }

                //This is if youre testing the cases where a prediction was made for a forest fire (True Case)
                /* float cost2 = 0;
                cost2 = ((weight1 * totalTP) + (weight2 * totalTN));     //Misclassification cost calculator
                //cout << "Missclassification Cost: " << cost << endl; [3]

                if (cost < minCost) {
                    minCost2 = cost2;             //record lowest cost
                    bestERC2 = testVal;          //record current ERC being tested
                }
                 */
 /*           }

            //cout << "---------------------------------------------------------------" << endl;
            //cout << endl;
            //cout << "          Lowest Misclass Cost: " << minCost << " at ERC: " << bestERC << endl;
            //cout << endl;
            //cout << "---------------------------------------------------------------" << endl;

            bestERCvals.push_back(bestERC);

        }

        displayResults();
    }

private:
    string filename;
    float weight1;
    float weight2;
    int iterationNum;
    vector<float> bestERCvals;

    void parseLine(const string& line, float testVal, int& totalTP, int& totalTN, int& totalFP, int& totalFN, StoreMatrix& storeMatrix) {
        size_t pos = line.find(',');
        string linenum = line.substr(0, pos);
        string remainingLine = line.substr(pos + 1);
        linenum.clear();

        pos = remainingLine.find(',');
        string date = remainingLine.substr(0, pos);
        remainingLine = remainingLine.substr(pos + 1);

        pos = remainingLine.find(',');
        float erc = stof(remainingLine.substr(0, pos));
        remainingLine = remainingLine.substr(pos + 1);
        int FD = stoi(remainingLine);

        int tpr = 0, tnr = 0, fpr = 0, fnr = 0;

        if (erc >= testVal && FD == 1) {
            tpr = 1;
            tnr = 0; // prediction is fire & there was a fire
            fpr = 0;
            fnr = 0;
        }
        if (erc >= testVal && FD == 0) {
            tpr = 0;
            tnr = 0; // prediction is fire & there was no fire.
            fpr = 1;
            fnr = 0;
        }
        if (erc < testVal && FD == 0) {
            tpr = 0;
            tnr = 1; // prediction is no fire & there was no fire.
            fpr = 0;
            fnr = 0;
        }
        if (erc < testVal && FD == 1) {
            tpr = 0;
            tnr = 0; // prediction is no fire & there was a fire.
            fpr = 0;
            fnr = 1;
        }

        // now you need to add ways to push values into the array
        ConfusionMatrix predFireAccuracy(erc, tpr, tnr, fpr, fnr); // will be used to make the prediction/obs matrix
        // predFireAccuracyWithDate.emplace(date,predFireAccuracy);//incase you wanted to map with date [not in use]
        storeMatrix.addConfusionMatrix(predFireAccuracy);

        // cout<< predFireAccuracy << endl;
        // cout << "This is the matrix: " << predFireAccuracy << endl; [1] //USE THIS TO TEST IF YOU WANT TO SEE ALL DATA OUTPUTS (TPR,TNR,FPR,FNR)
    }

    vector<pair<float, int>> trackValues(const vector<float>& bestERCvals) {
        unordered_map<float, int> count_map;
        for (float val : bestERCvals) {         //count occurances of certain "best" ERC vals (AKA THOSE WITH LOWEST FP FN RATE)
            count_map[val]++;
        }
        return vector<pair<float, int>>(count_map.begin(), count_map.end());
    }

    void displayResults() {
        vector<pair<float, int>> counts_vector = trackValues(bestERCvals);
        for (const auto& pair : counts_vector) {     //[4]
            float tempVar = pair.second;
            //float tempVal = pair.first;
            cout << "Value: " << pair.first << ", Count: " << pair.second << ", Percentage: " << float((tempVar / iterationNum) * 100) << "%" << endl;
            //could implement so it has only top 4 vals but not super necessary.
        }
    }
};

 */