#include <iostream>
#include <vector>
#include <array>
#include <map>
using namespace std;


class StoreMatrix {
public:
    map<float, array<int, 4>> _oneTallies;              // ERC to a tally array for occurrences of 1 in each position
    vector<StoreMatrix> storeMatrix;

    StoreMatrix() : storeMatrix() {}
    StoreMatrix(float erc, int tpr, int tnr, int fpr, int fnr) : erc(erc), tpr(tpr), tnr(tnr), fpr(fpr), fnr(fnr) {}              //initialize empty vector

    void addConfusionMatrix(const float _erc,const int _tpr,const int _tnr, const int _fpr, const int _fnr) {         //pulls confusion matrix
        float erc = _erc;

        if (_oneTallies.find(erc) == _oneTallies.end()) {               //.end() meaning no value is found with that erc
            _oneTallies[erc].fill(0);                                   // If ERC is not found, initialize tallies with 0 | just an error case shouldn't ever be used.
        }

        _oneTallies[erc][0] += _tpr == 1 ? 1 : 0;
        _oneTallies[erc][1] += _tnr == 1 ? 1 : 0;      // Increment tally based on the occurrence of 1 in each position
        _oneTallies[erc][2] += _fpr == 1 ? 1 : 0;
        _oneTallies[erc][3] += _fnr == 1 ? 1 : 0;
    }

    array<int, 4> getOneTallies(float erc) const {
        if (_oneTallies.find(erc) != _oneTallies.end()) {
            return _oneTallies.at(erc);                             // Method to get the one tallies for a given ERC
        } else {
            return array<int, 4>();                                    // Return an empty array if ERC not found (make new array if case is not created)
        }
    }
private:
    float erc;
    int tpr;
    int tnr;
    int fpr;
    int fnr;
};