/*

 //Utilize with FirePredictionAnalyzer

#include <iostream>
#include "FirePredictionAnalyzer.cpp"

using namespace std;

int main() {
    cout << "Fire Prediction BootStrapped Analyzer " << endl;

    float weight1;
    float weight2;
    int iterationNum;
    int bootStrap;
    cout << "Please Input Your Intended Weight for Positive Cost: ";
    cin >> weight1;
    cout << "Please Input Your Intended Weight for Negative Cost: ";
    cin >> weight2;
    cout << "How many iterations do you wish to run?: ";
    cin >> iterationNum;

    FirePredictionAnalyzer analyzer("import.csv", weight1, weight2, iterationNum);
    analyzer.runAnalysis();

    return 0; //end program
}
 */