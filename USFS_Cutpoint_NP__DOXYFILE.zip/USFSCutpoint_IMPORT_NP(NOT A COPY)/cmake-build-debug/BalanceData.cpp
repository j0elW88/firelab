/**
 * @file BalanceData.h
 * @brief Defines the BalanceData class for handling and balancing data based on a given file.
 *
 * This class reads data from a file, processes it to find and balance records based on a specific column value,
 * and provides methods to access the balanced data.
 */

#include <fstream>
#include <iostream>
#include <random>
#include <algorithm>
#include <sstream>

using namespace std;

/**
 * @class BalanceData
 * @brief A class for reading, processing, and balancing data from a file.
 *
 * This class reads data from a specified file, identifies the index of a given column (FD),
 * and processes the data to balance it based on the values in the FD column.
 */
class BalanceData {
public:
    string headerLine;
    /**
     * @brief Constructor for the BalanceData class.
     * @param filename The name of the file to read data from.
     * @param fdFind The name of the column to find and use for balancing data.
     *
     * The constructor initializes the class by reading the file, finding the FD column index,
     * and balancing the data based on the FD column values.
     */
    BalanceData(const string &filename, string fdFind) {
        readFileLines(filename);
        findFdIndex(fdFind); // Calculate fdIndex once
        balanceData();
    }

    /**
     * @brief Destructor for the BalanceData class.
     *
     * The destructor cleans up dynamically allocated memory for fileLines and balancedData.
     */
    ~BalanceData() {
        delete fileLines;
        delete balancedData;
    }

    /**
     * @brief Retrieves the balanced data.
     * @return A vector of strings containing the balanced data.
     *
     * This method returns the data that has been balanced based on the FD column values.
     */
    vector<string> getBalancedData() {
        return *balancedData;
    }

    /**
     * @brief Getter for the FD index.
     * @return The index of the FD column in the data.
     *
     * This method returns the index of the FD column, which is used for balancing the data.
     */
    int getFdIndex() const {
        return fdIndex;
    }

    /**
     * @brief Finds the index of the FD column in the header line.
     * @param fdFind The name of the column to find.
     *
     * This method determines the index of the specified FD column by searching the header line.
     */
    void findFdIndex(string fdFind) {
        size_t fdPos = headerLine.find(fdFind);
        fdIndex = count(headerLine.begin(), headerLine.begin() + fdPos, ',');
    }

private:
    vector<string>* fileLines = new vector<string>; /**< Pointer to the vector of lines read from the file. */
    vector<string>* balancedData = new vector<string>; /**< Pointer to the vector of balanced data. */
    int fdIndex; /**< The index of the FD column in the data. */

    /**
     * @brief Reads the lines of the file into fileLines.
     * @param filename The name of the file to read data from.
     *
     * This method opens the specified file, reads its lines, and stores them in the fileLines vector.
     */
    void readFileLines(const string &filename) {
        ifstream file(filename);

        if (!file.is_open()) {
            cout << "Error opening input file, please check file name!" << endl;
            exit(1);
        }

        string line;
        getline(file, headerLine); // read header
        while (getline(file, line)) {
            fileLines->push_back(line); // store each line in the vector
        }

        file.close();
    }

    /**
     * @brief Retrieves a random sample from the provided data.
     * @param data The data to sample from.
     * @param sampleSize The size of the sample to retrieve.
     * @return A vector of strings containing the random sample.
     *
     * This method shuffles the data and selects a random sample of the specified size.
     */
    vector<string> getRandomSample(const vector<string> &data, size_t sampleSize) {
        vector<string> sample = data;
        random_device rd;
        mt19937 g(rd());
        shuffle(sample.begin(), sample.end(), g);
        sample.resize(sampleSize);
        return sample;
    }

    /**
     * @brief Balances the data based on the FD column values.
     *
     * This method separates the data into two groups based on the FD column value (1 or 0),
     * then selects a random sample from each group to ensure balanced data.
     */
    void balanceData() {
        vector<string> fd1Lines;
        vector<string> fd0Lines;

        // Separate lines based on FD value
        for (const string &line : *fileLines) {
            stringstream ss(line);
            string item;
            vector<string> tokens;

            while (getline(ss, item, ',')) {
                item.erase(remove(item.begin(), item.end(), '"'), item.end());
                tokens.push_back(item);
            }

            if (!tokens[fdIndex].empty() && all_of(tokens[fdIndex].begin(), tokens[fdIndex].end(), ::isdigit)) {
                int fd = stoi(tokens[fdIndex]);
                if (fd == 1) {
                    fd1Lines.push_back(line);
                } else {
                    fd0Lines.push_back(line);
                }
            } else {
                cout << "Invalid FD value: " << tokens[fdIndex] << endl;
                continue;
            }
        }

        // Balance the data
        size_t minSize = min(fd1Lines.size(), fd0Lines.size());
        *balancedData = getRandomSample(fd1Lines, minSize);
        vector<string> balancedFD0Lines = getRandomSample(fd0Lines, minSize);

        balancedData->insert(balancedData->end(), balancedFD0Lines.begin(), balancedFD0Lines.end());
    }
};
