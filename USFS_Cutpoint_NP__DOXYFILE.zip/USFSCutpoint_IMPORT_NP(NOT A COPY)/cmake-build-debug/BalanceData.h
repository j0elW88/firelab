//
// Created by jwoeste on 5/30/24.
//

#ifndef CUTPOINT_BALANCEDATA_H
#define CUTPOINT_BALANCEDATA_H


class BalanceData {

};


#endif //CUTPOINT_BALANCEDATA_H
