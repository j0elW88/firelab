/**
 * @file StoreMatrix.h
 * @brief Defines the StoreMatrix class for managing and processing confusion matrix data.
 * 
 * This class provides functionalities for storing, updating, and retrieving confusion matrix tallies
 * associated with different ERC (Event Related Column) values. It includes methods to add confusion matrices
 * and retrieve tallies for a specific ERC value.
 */

#include <iostream>
#include <vector>
#include <array>
#include <map>
using namespace std;

/**
 * @class StoreMatrix
 * @brief A class for managing confusion matrix data and associated tallies.
 * 
 * The StoreMatrix class maintains a map from ERC values to an array of tallies for confusion matrix positions,
 * and provides methods to add confusion matrix data and retrieve tallies for specific ERC values.
 */
class StoreMatrix {
public:
    /**
     * @brief Map from ERC values to an array of tallies.
     * 
     * This map associates each ERC value with an array of four integers representing tallies for occurrences
     * of the values 1 in different positions of the confusion matrix.
     */
    map<float, array<int, 4>> _oneTallies;

    /**
     * @brief Vector of StoreMatrix instances.
     * 
     * This vector is used to store multiple instances of StoreMatrix. It is initialized as an empty vector
     * in the default constructor.
     */
    vector<StoreMatrix> storeMatrix;

    /**
     * @brief Default constructor for the StoreMatrix class.
     * 
     * Initializes an empty vector for storeMatrix.
     */
    StoreMatrix() : storeMatrix() {}

    /**
     * @brief Parameterized constructor for the StoreMatrix class.
     * @param erc Pointer to an array of float values representing ERC values.
     * @param tpr Pointer to an integer representing true positive rate.
     * @param tnr Pointer to an integer representing true negative rate.
     * @param fpr Pointer to an integer representing false positive rate.
     * @param fnr Pointer to an integer representing false negative rate.
     * 
     * Initializes the class with the given pointers to data.
     */
    StoreMatrix(float* erc, int* tpr, int* tnr, int* fpr, int* fnr) : erc(erc), tpr(tpr), tnr(tnr), fpr(fpr), fnr(fnr) {}

    /**
     * @brief Adds a confusion matrix to the tallies.
     * @param _erc The ERC value associated with the confusion matrix.
     * @param _tpr The true positive rate (1 or 0).
     * @param _tnr The true negative rate (1 or 0).
     * @param _fpr The false positive rate (1 or 0).
     * @param _fnr The false negative rate (1 or 0).
     * 
     * Updates the tallies for the given ERC value based on the provided confusion matrix rates.
     */
    void addConfusionMatrix(const float _erc, const int _tpr, const int _tnr, const int _fpr, const int _fnr) {
        float erc = _erc;

        if (_oneTallies.find(erc) == _oneTallies.end()) {
            _oneTallies[erc].fill(0); // If ERC is not found, initialize tallies with 0
        }

        // Increment tally based on the occurrence of 1 in each position
        _oneTallies[erc][0] += _tpr == 1 ? 1 : 0;
        _oneTallies[erc][1] += _tnr == 1 ? 1 : 0;
        _oneTallies[erc][2] += _fpr == 1 ? 1 : 0;
        _oneTallies[erc][3] += _fnr == 1 ? 1 : 0;
    }

    /**
     * @brief Retrieves the tallies for a given ERC value.
     * @param erc The ERC value for which tallies are to be retrieved.
     * @return An array of four integers representing the tallies for the given ERC value.
     * 
     * This method returns the tallies for the specified ERC value if it exists in the map.
     * If the ERC value is not found, it returns an empty array.
     */
    array<int, 4> getOneTallies(float erc) const {
        if (_oneTallies.find(erc) != _oneTallies.end()) {
            return _oneTallies.at(erc); // Return the tallies for the given ERC value
        } else {
            return array<int, 4>(); // Return an empty array if ERC not found
        }
    }

private:
    float* erc = new float(); /**< Pointer to a float representing ERC value (not used in provided code). */
    int* tpr = new int(); /**< Pointer to an integer representing true positive rate (not used in provided code). */
    int* tnr = new int(); /**< Pointer to an integer representing true negative rate (not used in provided code). */
    int* fpr = new int(); /**< Pointer to an integer representing false positive rate (not used in provided code). */
    int* fnr = new int(); /**< Pointer to an integer representing false negative rate (not used in provided code). */
};

