/**
 * @file main.cpp
 * @brief HOW USFSCUTPOINT_IMPORT_NP or Cutpoint Analysis Program Works


Cutpoint Works by intaking a file that contains a percentiled (or not) value as a anchor for another input of binary data,
in previous test cases we have used the example of ERC_PRC and FD. These two outputs can be
obtained through running USFS_NP_SORT that compiles IFAD and Weather data to create accurate
merged FD, also able to run equations on DATA.

This program works very generally to allow for variability in data inputs!
This program intakes the data, and randomly samples until the size of the larger
binary line is equal in size, FD = 0 is equal in size to FD = 1.
After this is achieved it will assign the values True Posotive, True Negative, False Posotive, and False Negative Values
Currently Only the False Posotive and Negative Cases are considered for ERC ranking, the posotive cases
are used to evaluate total outcome accuracy. After data is sorted into TP TN FP FN, the anchor values or ERC's are tallied
whichever value for that run has the least cost after a weighting cost is applied. After the optimal erc for this run is found, depending on the users run amount,
the program will recompile for that amount of times over again. After recompiling x amount of times, the
best ERC or the most frequently achieved ERC from each of these runs is found, and if it is split between the middle, it will take the average between the two
After this, the program runs through the different weight categories assigned. Standard as of now
it runs through a 1:5, 1:2, 1:1, 2:1, 5:1 weighting scale, which should ultimately output your cutpoint values.
 */

#include <iostream>
#include <cmath>
#include <vector>
#include <string>
#include <sstream>
#include <unordered_map>
#include "BalanceData.cpp"
#include "StoreMatrix.cpp"

using namespace std;

/**
 * @brief Tracks occurrences of each value in the provided vector.
 *
 * @param bestERCvals A vector of float values representing the best ERC values.
 * @return A vector of pairs where each pair consists of a float value and its count of occurrences.
 */
vector<pair<float, int>> track_values(const vector<float>& bestERCvals) {
    unordered_map<float, int> count_map;

    // Count occurrences of each value
    for (float val : bestERCvals) {
        count_map[val]++;
    }

    // Convert counts to a vector of pairs
    vector<pair<float, int>> counts_vector(count_map.begin(), count_map.end());
    return counts_vector;
}

/**
 * @brief The main function for the FIRE ANALYSIS CUTPOINT program.
 *
 * This function prompts the user for input, processes fire and weather data to find optimal ERC scaling factors or cutpoints and
 * classification accuracy for different scales, and outputs the results to the command line (can be made to output to variables very easily).
 *
 * @return int Returns 0 on successful execution, or 1 if requested variables are not found.
 * @return Also Returns the scale factors of 1:5,1:2,1:1,2:1,5:1 after all runs
 * For the following code, the ERC title(or whatever column value you choose to compare) must be placed in the ercFind variable, and the binary value column name you wish to bind to these values should be placed in the fdFind variable in current case ERC_REL and FD are used.
 */
int main() {
    cout << "FIRE ANALYSIS CUTPOINT \nPlease Make Sure You Input A FileName and a Searchable Value!" << endl;

    int weight1;
    int weight2;
    int iterationNum;

    // ERC scale and best class value pointers
    float *ERCscale15 = new float(0.0f);  // Scale factor for 1:5
    float *ERCscale12 = new float(0.0f);  // Scale factor for 1:2
    float *ERCscale1_1 = new float(0.0f); // Scale factor for 1:1
    float *ERCscale21 = new float(0.0f);  // Scale factor for 2:1
    float *ERCscale51 = new float(0.0f);  // Scale factor for 5:1

    float *bestClassVal15 = new float(0.0f);  // Best class value for scale 1:5
    float *bestClassVal12 = new float(0.0f);  // Best class value for scale 1:2
    float *bestClassVal1_1 = new float(0.0f); // Best class value for scale 1:1
    float *bestClassVal21 = new float(0.0f);  // Best class value for scale 2:1
    float *bestClassVal51 = new float(0.0f);  // Best class value for scale 5:1


    string ercFind = "ERC_REL";
    string fdFind = "FD";

    cout << "How many iterations do you wish to run?: ";
    cin >> iterationNum;
    cout << endl;
    cout << "CURRENTLY SET TO FIND: " + ercFind + " AND " + fdFind << endl;


    BalanceData balanceData("output.csv",fdFind);
    string headerVariables = balanceData.headerLine;

    size_t ercRelPos = headerVariables.find(ercFind);
    size_t fdPos = headerVariables.find(fdFind);   //RECENTLY WE MOVED TO FIRE OCCURANCE INSTEAD OF FIRE DAYS!

    if (ercRelPos == string::npos || fdPos == string::npos) {
        cout << "One or more requested variables not found in the header." << endl;
        return 1;
    }

    // Calculate ERC index
    int ercRelIndex = 0;
    for (int i = 0; i < ercRelPos; ++i) {
        if (headerVariables[i] == ',') {
            ercRelIndex++;
        }
    }

    // Calculate FD index
    balanceData.findFdIndex(fdFind);  // Call findFdIndex to calculate fdIndex
    int fdIndex = balanceData.getFdIndex();  // Get fdIndex from BalanceData

    int numRuns = 5;  // Program runs 5 times to find all scales!
    for (int scaleRun = 0; scaleRun < numRuns; ++scaleRun) {
        switch (scaleRun) {
            case 0:
                weight1 = 1;
                weight2 = 5;
                break;
            case 1:
                weight1 = 1;
                weight2 = 2;
                break;
            case 2:
                weight1 = 1;
                weight2 = 1;
                break;
            case 3:
                weight1 = 2;
                weight2 = 1;
                break;
            case 4:
                weight1 = 5;
                weight2 = 1;
                break;
        }

        vector<float> bestERCvals;  // Vector to store best ERC values for each iteration
        vector<float> classAccuracyVals;  // Vector to store class accuracy values for each iteration

        for (int iteration = 0; iteration < iterationNum; ++iteration) {

            vector<string> balancedData = balanceData.getBalancedData();
            float minCost = 999999999.0f;  // Initialize minimum cost with a large value
            float classVal = 0.0f;  // Variable to store class value
            float bestERC = 0.0f;  // Variable to store the best ERC value

            for (float i = 0.00f; i <= 1.00f; i += 0.01f) {
                float testVal = i;

                int totalFP = 0;  // Total false positives
                int totalFN = 0;  // Total false negatives
                int totalTP = 0;  // Total true positives
                int totalTN = 0;  // Total true negatives

                StoreMatrix storeMatrix;

                // Extract PRC_ERC values
                vector<float> tempERCValues(balancedData.size());
                for (size_t i = 0; i < balancedData.size(); ++i) {
                    stringstream ss(balancedData[i]);
                    string columnValue;
                    for (int j = 0; j <= ercRelIndex; ++j) {
                        getline(ss, columnValue, ',');
                    }
                    tempERCValues[i] = stof(columnValue);
                }

                // Extract FD values
                vector<int> tempFDValues(balancedData.size());
                for (size_t i = 0; i < balancedData.size(); ++i) {
                    stringstream ss(balancedData[i]);
                    string columnValue;
                    for (int j = 0; j <= fdIndex; ++j) {
                        getline(ss, columnValue, ',');
                    }
                    tempFDValues[i] = stoi(columnValue);
                }

                for (const string& line : balancedData) {
                    try {
                        stringstream ss(line);
                        vector<string> columnsVector;
                        string column;

                        while (getline(ss, column, ',')) {
                            columnsVector.push_back(column);
                        }

                        if (columnsVector.size() > max(ercRelIndex, fdIndex)) {
                            float erc = stof(columnsVector[ercRelIndex]);
                            int FD = stoi(columnsVector[fdIndex]);

                            int tpr = 0;  // True positive rate
                            int tnr = 0;  // True negative rate
                            int fpr = 0;  // False positive rate
                            int fnr = 0;  // False negative rate

                            if (erc >= testVal && FD == 1) {
                                tpr = 1;
                            }
                            if (erc >= testVal && FD == 0) {
                                fpr = 1;
                            }
                            if (erc < testVal && FD == 0) {
                                tnr = 1;
                            }
                            if (erc < testVal && FD == 1) {
                                fnr = 1;
                            }

                            storeMatrix.addConfusionMatrix(erc, tpr, tnr, fpr, fnr);
                        }

                    } catch (const invalid_argument& e) {
                        cerr << "Error: Invalid argument encountered while parsing the input data." << endl;
                        cerr << "Details: " << e.what() << endl;
                    }
                }

                for (const auto& entry : storeMatrix._oneTallies) {
                    float targetERC = entry.first;
                    auto tallies = storeMatrix.getOneTallies(targetERC);

                    totalTP += tallies[0];
                    totalTN += tallies[1];
                    totalFP += tallies[2];
                    totalFN += tallies[3];
                }

                // Update best ERC and class value if current cost is lower
                float cost = (weight1 * totalFN) + (weight2 * totalFP);
                float cost2 = (totalTP + totalTN) / (float)(totalFN + totalFP + totalTP + totalTN); // Class Accuracy

                if (cost < minCost) {
                    bestERC = testVal;
                    minCost = cost;
                    classVal = cost2;
                }
            }

            bestERCvals.push_back(bestERC); // Store best ERC value for current iteration
            classAccuracyVals.push_back(classVal); // Store class accuracy value for current iteration
        }

        /**
         * @return Note for calculating bestClassVal and ERCscale, which are at the bottom of code and deal with main calculations
         * This portion calculates the mean of two contested bestERC values if they have the same frequency
         * The following portion assigns the bestERC's to the output, changing based on the scaling
         *  Best class value is also assigned in order to track the accuracy of the "bestERC", mostly for testing sake.
         * ERC VALS ARE ROUNDED IN THE END TO THE 100th PLACE
         */

        float maxERCcount = -999999.0f; // Initialize maximum ERC count with a small value
        for (const auto& pair : track_values(bestERCvals)) {
            if (maxERCcount == pair.second) {
                switch (scaleRun) {
                    case 0:     //FIX THIS PART ASWELL IN ACTUAL CODE
                        *ERCscale15 = (*ERCscale15 + pair.first) / 2;
                        *bestClassVal15 = (*bestClassVal15 + classAccuracyVals.back()) / 2;
                        *ERCscale15 = round(*ERCscale15 * 100.0) / 100.0;
                        cout << "Splitting for 1:5" << endl;
                        break;
                    case 1:
                        *ERCscale12 = (*ERCscale12 + pair.first) / 2;
                        *bestClassVal12 = (*bestClassVal12 + classAccuracyVals.back()) / 2;
                        *ERCscale12 = round(*ERCscale12 * 100.0) / 100.0;
                        cout << "Splitting for 1:2" << endl;
                        break;
                    case 2:
                        *ERCscale1_1 = (*ERCscale1_1 + pair.first) / 2;
                        *bestClassVal1_1 = (*bestClassVal1_1 + classAccuracyVals.back()) / 2;   //USED TO SPLIT MIDDLE IF TWO BEST ERC's ARE CONTESTED
                        *ERCscale1_1 = round(*ERCscale1_1 * 100.0) / 100.0;
                        cout << "Splitting for 1:1" << endl;
                        break;
                    case 3:
                        *ERCscale21 = (*ERCscale21 + pair.first) / 2;
                        *bestClassVal21 = (*bestClassVal21 + classAccuracyVals.back()) / 2;
                        *ERCscale21 = round(*ERCscale21 * 100.0) / 100.0;
                        cout << "Splitting for 2:1" << endl;
                        break;
                    case 4:
                        *ERCscale51 = (*ERCscale51 + pair.first) / 2;
                        *bestClassVal51 = (*bestClassVal51 + classAccuracyVals.back()) / 2;
                        *ERCscale51 = round(*ERCscale51 * 100.0) / 100.0;
                        cout << "Splitting for 5:1" << endl;
                        break;
                }
                maxERCcount = pair.second;
            } else if (maxERCcount < pair.second) {
                switch (scaleRun) {
                    case 0:
                        *ERCscale15 = pair.first;
                        *bestClassVal15 = classAccuracyVals.back();
                        cout << "Calculating 1:5" << endl;
                        break;
                    case 1:
                        *ERCscale12 = pair.first;
                        *bestClassVal12 = classAccuracyVals.back();
                        cout << "Calculating 1:2" << endl;
                        break;
                    case 2:
                        *ERCscale1_1 = pair.first;
                        *bestClassVal1_1 = classAccuracyVals.back();         //PICKS BEST BEST ERC FOR EACH RUN AND OUTPUTS
                        cout << "Calculating 1:1" << endl;
                        break;
                    case 3:
                        *ERCscale21 = pair.first;
                        *bestClassVal21 = classAccuracyVals.back();
                        cout << "Calculating 2:1" << endl;
                        break;
                    case 4:
                        *ERCscale51 = pair.first;
                        *bestClassVal51 = classAccuracyVals.back();
                        cout << "Calculating 5:1" << endl;
                        break;
                }
                maxERCcount = pair.second;
            }
        }
    }


    *ERCscale15 = round(*ERCscale15 * 100) / 100;
    *ERCscale12 = round(*ERCscale12 * 100) / 100;
    *ERCscale1_1 = round(*ERCscale1_1 * 100) / 100;
    *ERCscale21 = round(*ERCscale21 * 100) / 100;
    *ERCscale51 = round(*ERCscale51 * 100) / 100;

    *bestClassVal15 = round(*bestClassVal15 * 100) / 100;
    *bestClassVal12 = round(*bestClassVal12 * 100) / 100;
    *bestClassVal1_1 = round(*bestClassVal1_1 * 100) / 100;
    *bestClassVal21 = round(*bestClassVal21 * 100) / 100;
    *bestClassVal51 = round(*bestClassVal51 * 100) / 100;

    cout << endl;
    cout << "---------------------------------------------------------------" << endl;
    cout << "              Best ERC Scaling Factors: " << endl;
    cout << "                 Scale 1:5: " << *ERCscale15 << " with Classification Accuracy: " << *bestClassVal15 << endl;
    cout << "                 Scale 1:2: " << *ERCscale12 << " with Classification Accuracy: " << *bestClassVal12 << endl;
    cout << "                 Scale 1:1: " << *ERCscale1_1 << " with Classification Accuracy: " << *bestClassVal1_1 << endl;
    cout << "                 Scale 2:1: " << *ERCscale21 << " with Classification Accuracy: " << *bestClassVal21 << endl;
    cout << "                 Scale 5:1: " << *ERCscale51 << " with Classification Accuracy: " << *bestClassVal51 << endl;
    cout << "---------------------------------------------------------------" << endl;

    // Free allocated memory
    delete ERCscale15;
    delete ERCscale12;
    delete ERCscale1_1;
    delete ERCscale21;
    delete ERCscale51;

    delete bestClassVal15;
    delete bestClassVal12;
    delete bestClassVal1_1;
    delete bestClassVal21;
    delete bestClassVal51;

    return 0;
}
