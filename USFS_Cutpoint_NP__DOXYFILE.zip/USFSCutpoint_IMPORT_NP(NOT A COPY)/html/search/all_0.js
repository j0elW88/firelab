var searchData=
[
  ['_5fonetallies_0',['_oneTallies',['../classStoreMatrix.html#a611245e4c8828883ef1599c73cd34bd1',1,'StoreMatrix']]]
];
