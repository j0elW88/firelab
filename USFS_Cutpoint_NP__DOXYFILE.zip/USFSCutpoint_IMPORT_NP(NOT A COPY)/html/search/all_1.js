var searchData=
[
  ['addconfusionmatrix_0',['addConfusionMatrix',['../classStoreMatrix.html#a32b4fddb758f4b7b3b9f7949dad82a7d',1,'StoreMatrix']]]
];
