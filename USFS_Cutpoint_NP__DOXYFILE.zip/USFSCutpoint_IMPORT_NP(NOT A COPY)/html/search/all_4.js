var searchData=
[
  ['getbalanceddata_0',['getBalancedData',['../classBalanceData.html#a55b79e9047204756585ac94151a44a5c',1,'BalanceData']]],
  ['getfdindex_1',['getFdIndex',['../classBalanceData.html#ad41137869431b4d11cce17374504518c',1,'BalanceData']]],
  ['getonetallies_2',['getOneTallies',['../classStoreMatrix.html#aa0241912337f4e0b562e683c6e0a44ef',1,'StoreMatrix']]]
];
