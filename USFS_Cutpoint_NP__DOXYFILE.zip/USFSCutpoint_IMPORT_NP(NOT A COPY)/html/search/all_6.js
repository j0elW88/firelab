var searchData=
[
  ['storematrix_0',['StoreMatrix',['../classStoreMatrix.html',1,'']]],
  ['storematrix_1',['storeMatrix',['../classStoreMatrix.html#a05ed643ab2e51324c565396473197955',1,'StoreMatrix']]],
  ['storematrix_2',['StoreMatrix',['../classStoreMatrix.html#af8e0d1d4725698ff4c2466a219b2884a',1,'StoreMatrix::StoreMatrix()'],['../classStoreMatrix.html#a6a05ca46dcdd555e66c98c88100dc3ad',1,'StoreMatrix::StoreMatrix(float *erc, int *tpr, int *tnr, int *fpr, int *fnr)']]],
  ['storematrix_2eh_3',['StoreMatrix.h',['../StoreMatrix_8h.html',1,'']]]
];
