var searchData=
[
  ['storematrix_0',['StoreMatrix',['../classStoreMatrix.html#af8e0d1d4725698ff4c2466a219b2884a',1,'StoreMatrix::StoreMatrix()'],['../classStoreMatrix.html#a6a05ca46dcdd555e66c98c88100dc3ad',1,'StoreMatrix::StoreMatrix(float *erc, int *tpr, int *tnr, int *fpr, int *fnr)']]]
];
