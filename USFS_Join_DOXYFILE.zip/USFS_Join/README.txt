HOW USFSJOIN WORKS 

Join is a very generic program that works by using the first file input as a DateTime Anchor,
Based on the dates provided in the first file, data from the second file are scraped if they contain
a matching date, if they match, the data is added to a vector that outputs both the original contents
of the first file, along side the data minus the date, from the second file.

This can be used generically for pretty much any file append, but be aware if the first file contains
less data points than the second file, the second files data will be cropped to match the first file
in this case, if you do not wish for data to be removed, either make sure the dates are matching, or swap the order of 
the file import.
