#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <unordered_map>
#include <algorithm>

using namespace std;

/**
 * @brief main.cpp
 * @return HOW USFSJOIN WORKS
    Join is a very generic program that works by using the first file input as a DateTime Anchor,
    Based on the dates provided in the first file, data from the second file are scraped if they contain
    a matching date, if they match, the data is added to a vector that outputs both the original contents
    of the first file, along side the data minus the date, from the second file.

    This can be used generically for pretty much any file append, but be aware if the first file contains
    less data points than the second file, the second files data will be cropped to match the first file
    in this case, if you do not wish for data to be removed, either make sure the dates are matching, or swap the order of
    the file import.
 */


/**
 * @brief Removes quotes from the beginning and end of a string.
 *
 * This function checks if the input string has quotes at the start and end,
 * and if so, it removes them.
 *
 * @param s The input string to be processed.
 * @return The string without leading and trailing quotes.
 */

// Function to remove quotes from a string
string trimQuotes(const string& s) {
    if (s.empty()) return s;
    if (s.front() == '"' && s.back() == '"') {
        return s.substr(1, s.size() - 2);
    }
    return s;
}

/**
 * @brief Removes carriage return characters from a string.
 *
 * This function removes all carriage return characters ('\r') from the input string.
 *
 * @param s The input string to be processed.
 * @return The string with carriage returns removed.
 */

// Function to remove carriage returns
string removeCarriageReturns(const string& s) {
    string result = s;
    result.erase(remove(result.begin(), result.end(), '\r'), result.end());
    return result;
}

/**
 * @brief Finds the index of a specific column by its name.
 *
 * This function searches for a column name in the vector of header strings
 * and returns its index. If the column name is not found, it returns -1.
 *
 * @param headers A vector of header strings.
 * @param columnName The name of the column to find.
 * @return The index of the column if found, otherwise -1.
 */


// Function to find the index of a specific column by name
int findColumnIndex(const vector<string>& headers, const string& columnName) {
    auto it = find(headers.begin(), headers.end(), columnName);
    if (it != headers.end()) {
        return distance(headers.begin(), it);
    }
    return -1; // Not found
}

/**
 * @brief Main function for processing CSV files and merging data.
 *
 * This function reads data from two CSV files, merges them based on the date column,
 * and writes the combined data to a new CSV file.
 * argv and argc arent used
 * @return returns a combined file using the fire file input as a date anchor for the second file.
 */

int main(int argc, char *argv[]) {
    string firstFile = "output.csv";
    string combineFile = "IFAD_Lolo.csv";
    string fileExport = "output2.csv";

    vector<string> firstFileLines;
    unordered_map<string, vector<string>> dateToColumns;

    // Read the first file
    ifstream file(firstFile);
    if (!file.is_open()) {
        cerr << "Error opening file: " << firstFile << endl;
        return 1;
    }

    string header;
    getline(file, header); // Read header line
    header = removeCarriageReturns(header);
    vector<string> firstFileHeaders;
    stringstream headerStream(header);
    string column;
    while (getline(headerStream, column, ',')) {
        firstFileHeaders.push_back(trimQuotes(column));
    }

    string line;
    while (getline(file, line)) {
        line = removeCarriageReturns(line);
        firstFileLines.push_back(line);
    }
    file.close();

    // Read the combine file and map dates to their columns
    ifstream combinefile(combineFile);
    if (!combinefile.is_open()) {
        cerr << "Error opening file: " << combineFile << endl;
        return 1;
    }

    string combineHeader;
    getline(combinefile, combineHeader); // Read header line
    combineHeader = removeCarriageReturns(combineHeader);
    vector<string> combineHeaders;
    stringstream combineHeaderStream(combineHeader);
    while (getline(combineHeaderStream, column, ',')) {
        combineHeaders.push_back(trimQuotes(column));
    }

    // Find the index of the DateTime column in the combine file
    int combineDateIndex = findColumnIndex(combineHeaders, "DateTime");

    if (combineDateIndex == -1) {
        cerr << "DateTime column not found in combine file" << endl;
        return 1;
    }

    while (getline(combinefile, line)) {
        line = removeCarriageReturns(line);
        stringstream ss(line);
        vector<string> columns;
        while (getline(ss, column, ',')) {
            columns.push_back(trimQuotes(column));
        }

        if (!columns.empty() && combineDateIndex < columns.size()) {
            string date = columns[combineDateIndex].substr(0, 10); // Extract Date
            dateToColumns[date] = vector<string>(columns.begin(), columns.end());
        }
    }
    combinefile.close();

    // Find the index of the DateTime column in the first file
    int firstFileDateIndex = findColumnIndex(firstFileHeaders, "DateTime");

    if (firstFileDateIndex == -1) {
        cerr << "DateTime column not found in first file" << endl;
        return 1;
    }

    // Write the output file
    ofstream outputFile(fileExport);
    if (!outputFile.is_open()) {
        cerr << "Error opening output file: " << fileExport << endl;
        return 1;
    }

    // Output header
    outputFile << header;
    if (combineHeaders.size() > combineDateIndex) {
        for (size_t i = 0; i < combineHeaders.size(); ++i) {
            if (i != combineDateIndex) {
                outputFile << "," << combineHeaders[i];
            }
        }
    }

    // Write first file data and append columns from the combine file
    for (const auto& fileLine : firstFileLines) {
        stringstream ss(fileLine);
        vector<string> fileColumns;
        while (getline(ss, column, ',')) {
            fileColumns.push_back(trimQuotes(column));
        }

        if (firstFileDateIndex < fileColumns.size()) {
            string date = fileColumns[firstFileDateIndex].substr(0, 10); // Extract Date

            outputFile << "\n" << fileLine; // Write original line

            if (dateToColumns.find(date) != dateToColumns.end()) {
                for (size_t i = 0; i < dateToColumns[date].size(); ++i) {
                    if (i != combineDateIndex) {
                        outputFile << "," << dateToColumns[date][i]; // Append columns from combine file
                    }
                }
            } else {
                // Fill with empty columns if date not found
                for (size_t i = 0; i < combineHeaders.size(); ++i) {
                    if (i != combineDateIndex) {
                        outputFile << ",";
                    }
                }
            }
        }
    }

    outputFile.close();
    cout << "Program Complete! Data Exported to: " << fileExport << endl;
    return 0;
}
